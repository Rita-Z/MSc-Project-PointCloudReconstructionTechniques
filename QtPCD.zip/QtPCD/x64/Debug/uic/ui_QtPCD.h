/********************************************************************************
** Form generated from reading UI file 'QtPCD.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QTPCD_H
#define UI_QTPCD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QtPCDClass
{
public:
    QAction *actionscale_1;
    QAction *actionExit;
    QAction *actionscale_1000;
    QAction *actionscale_10;
    QWidget *centralWidget;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *QtPCDClass)
    {
        if (QtPCDClass->objectName().isEmpty())
            QtPCDClass->setObjectName(QString::fromUtf8("QtPCDClass"));
        QtPCDClass->resize(1600, 900);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(QtPCDClass->sizePolicy().hasHeightForWidth());
        QtPCDClass->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamily(QString::fromUtf8("Consolas"));
        QtPCDClass->setFont(font);
        actionscale_1 = new QAction(QtPCDClass);
        actionscale_1->setObjectName(QString::fromUtf8("actionscale_1"));
        actionscale_1->setFont(font);
        actionExit = new QAction(QtPCDClass);
        actionExit->setObjectName(QString::fromUtf8("actionExit"));
        actionscale_1000 = new QAction(QtPCDClass);
        actionscale_1000->setObjectName(QString::fromUtf8("actionscale_1000"));
        actionscale_1000->setFont(font);
        actionscale_10 = new QAction(QtPCDClass);
        actionscale_10->setObjectName(QString::fromUtf8("actionscale_10"));
        centralWidget = new QWidget(QtPCDClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        QtPCDClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(QtPCDClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1600, 29));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuFile->setFont(font);
        QtPCDClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(QtPCDClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        QtPCDClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(QtPCDClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        QtPCDClass->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuFile->addAction(actionscale_1);
        menuFile->addAction(actionscale_10);
        menuFile->addAction(actionscale_1000);

        retranslateUi(QtPCDClass);

        QMetaObject::connectSlotsByName(QtPCDClass);
    } // setupUi

    void retranslateUi(QMainWindow *QtPCDClass)
    {
        QtPCDClass->setWindowTitle(QCoreApplication::translate("QtPCDClass", "QtPCD", nullptr));
        actionscale_1->setText(QCoreApplication::translate("QtPCDClass", "scale 1", nullptr));
        actionExit->setText(QCoreApplication::translate("QtPCDClass", "Exit", nullptr));
        actionscale_1000->setText(QCoreApplication::translate("QtPCDClass", "scale 1000", nullptr));
        actionscale_10->setText(QCoreApplication::translate("QtPCDClass", "scale 10", nullptr));
        menuFile->setTitle(QCoreApplication::translate("QtPCDClass", "STL file", nullptr));
    } // retranslateUi

};

namespace Ui {
    class QtPCDClass: public Ui_QtPCDClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QTPCD_H
