#include "QtPCD.h"
#include <QFileDialog>

#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>   

using namespace std;

QtPCD::QtPCD(QWidget* parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);

	connect(ui.actionscale_1, SIGNAL(triggered()), this, SLOT(stlScale1()));
	connect(ui.actionscale_10, SIGNAL(triggered()), this, SLOT(stlScale10()));
	connect(ui.actionscale_1000, SIGNAL(triggered()), this, SLOT(stlScale1000()));
}

// void paintEvent(QPaintEvent*)
// Paint the figure as design.
void QtPCD::paintEvent(QPaintEvent*)
{
	QPainter painter(this);
	// pen setting
	QPen pen;
	pen.setWidth(2);  // size
	pen.setBrush(QColor(188, 159, 119));  // colour
	painter.setPen(pen);  // select
	// box setting
	QRect box;
	box.setX(XMARGIN);
	box.setY(YMARGIN);
	box.setWidth(XWIDTH);
	box.setHeight(YHEIGHT);
	// box filling colour
	QBrush brush(Qt::SolidPattern);
	brush.setColor(QColor(252, 250, 242));
	painter.setBrush(brush);
	painter.drawRect(box);
	// cut-off rule
	pen.setStyle(Qt::DashLine);
	pen.setWidth(2);
	pen.setColor(QColor(189, 192, 186));
	painter.setPen(pen);
	// horizontal line
	painter.drawLine(XMARGIN, YMARGIN + YHEIGHT / 4, XMARGIN + XWIDTH, YMARGIN + YHEIGHT / 4);
	painter.drawLine(XMARGIN, YMARGIN + YHEIGHT / 2, XMARGIN + XWIDTH, YMARGIN + YHEIGHT / 2);
	painter.drawLine(XMARGIN, YMARGIN + YHEIGHT / 4 * 3, XMARGIN + XWIDTH, YMARGIN + YHEIGHT / 4 * 3);
	// vertical line
	painter.drawLine(XMARGIN + XWIDTH / 4, YMARGIN, XMARGIN + XWIDTH / 4, YMARGIN + YHEIGHT);
	painter.drawLine(XMARGIN + XWIDTH / 2, YMARGIN, XMARGIN + XWIDTH / 2, YMARGIN + YHEIGHT);
	painter.drawLine(XMARGIN + XWIDTH / 4 * 3, YMARGIN, XMARGIN + XWIDTH / 4 * 3, YMARGIN + YHEIGHT);
	// number
	QFont axisFont("Consolas", 16);
	painter.setFont(axisFont);
	pen.setColor(QColor(67, 67, 67));
	painter.setPen(pen);
	painter.drawText(XMARGIN - 32 * 2.5 - 8, YMARGIN - 16 - 8, tr("theta"));
	painter.drawText(XMARGIN - 32 - 8, YMARGIN + 16 - 8, tr("PI"));
	painter.drawText(XMARGIN - 32 * 3 - 8 * 2, YMARGIN + 16 + YHEIGHT / 4 - 8, tr("3*PI/4"));
	painter.drawText(XMARGIN - 32 * 2 - 8 * 2, YMARGIN + 16 + YHEIGHT / 2 - 8, tr("PI/2"));
	painter.drawText(XMARGIN - 32 * 2 - 8 * 2, YMARGIN + 16 + YHEIGHT / 4 * 3 - 8, tr("PI/4"));
	painter.drawText(XMARGIN - 32 / 2 - 8, YMARGIN + 16 + YHEIGHT - 8, tr("0"));
	painter.drawText(XMARGIN, YMARGIN + 16 + YHEIGHT + 16, tr("phi"));
	painter.drawText(XMARGIN - 32 + XWIDTH / 4 - 4, YMARGIN + 16 + YHEIGHT + 16, tr("PI/2"));
	painter.drawText(XMARGIN - 32 + XWIDTH / 2 + 12, YMARGIN + 16 + YHEIGHT + 16, tr("PI"));
	painter.drawText(XMARGIN - 32 + XWIDTH / 4 * 3 - 16, YMARGIN + 16 + YHEIGHT + 16, tr("3*PI/2"));
	painter.drawText(XMARGIN - 32 + XWIDTH, YMARGIN + 16 + YHEIGHT + 16, tr("2*PI"));
	// point (normal)
	pen.setWidth(6);
	pen.setBrush(QColor(93, 172, 129));
	painter.setPen(pen);
	QPointF pointf;
	for (int i = 0; i < pointX.size(); ++i)
	{
		pointf.setX(pointX.at(i));
		pointf.setY(pointY.at(i));
		painter.drawPoint(pointf);
	}
}

// void stlScale1()
// Open STL file & use scale 1 sampling.
void QtPCD::stlScale1()
{
	QFileDialog dialog;
	dialog.setViewMode(QFileDialog::Detail);
	QString fileName = dialog.getOpenFileName(this,
		"Open STL file", "",
		"STL file (*.stl)");

	if (!fileName.isEmpty())
	{
		loadSTL(fileName.toStdString(), 1);
	}
}

// void stlScale10()
// Open STL file & use scale 10 sampling.
void QtPCD::stlScale10()
{
	QFileDialog dialog;
	dialog.setViewMode(QFileDialog::Detail);
	QString fileName = dialog.getOpenFileName(this,
		"Open STL file", "",
		"STL file (*.stl)");

	if (!fileName.isEmpty())
	{
		loadSTL(fileName.toStdString(), 10);
	}
}

// void stlScale1000()
// Open STL file & use scale 1000 sampling.
void QtPCD::stlScale1000()
{
	QFileDialog dialog;
	dialog.setViewMode(QFileDialog::Detail);
	QString fileName = dialog.getOpenFileName(this,
		"Open STL file", "",
		"STL file (*.stl)");

	if (!fileName.isEmpty())
	{
		loadSTL(fileName.toStdString(), 1000);
	}
}

// int loadSTL(string, int)
// Load STL file & obtain normal data 
// & change the value into sphere coordinate & update the figure.
int QtPCD::loadSTL(string fileName, int scale) {
	pointX.clear();
	pointY.clear();

	ifstream inFile(fileName);
	if (!inFile.is_open())
		return -1;
	string line, tempS;
	// initialisation
	float nx = 0.0f;
	float ny = 0.0f;
	float nz = 0.0f;
	int counter = 0;
	float tempnx, tempny, tempnz;
	float theta, phi;

	while (!inFile.eof()) {
		tempS = "";
		inFile >> tempS;
		// obtain normal data
		if (tempS == "facet") {
			inFile >> tempS;
			inFile >> tempnx >> tempny >> tempnz;
			nx += tempnx;
			ny += tempny;
			nz += tempnz;
			counter++;
			// do the sampling
			if (counter >= scale) {
				nx = nx / counter;
				ny = ny / counter;
				nz = nz / counter;
				// transform normal from XYZ coords into polar coords
				theta = atan2(sqrt(nx * nx + ny * ny), nz);
				phi = atan2(ny, nx);
				if (phi < 0) phi += 2 * PI;
				// store data
				pointY.push_back((PI - theta) * YHEIGHT / PI + YMARGIN);
				pointX.push_back(phi * XWIDTH / (2 * PI) + XMARGIN);
				// reset parameter
				counter = 0;
				nx = 0.0f;
				ny = 0.0f;
				nz = 0.0f;
			}
		}
		else if (tempS == "") {
		}
		// Ignore unnecessary data.
		else {
			getline(inFile, line);
		}

	}
	update();  // paint events
	return 0;
}
