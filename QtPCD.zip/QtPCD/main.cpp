#include "QtPCD.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QtPCD w;
    w.show();
    return a.exec();
}
