#pragma once

#include <QtWidgets/QMainWindow>
#include <QPainter>

#include <string>
#include "ui_QtPCD.h"

using namespace std;

// initialisation
const float PI = 3.1415926;
const int YMARGIN = 150;
const int XMARGIN = 200;
const int YHEIGHT = 600;
const int XWIDTH = 1200;

class QtPCD : public QMainWindow
{
	Q_OBJECT

public:
	QtPCD(QWidget* parent = Q_NULLPTR);
	void paintEvent(QPaintEvent*);  // painter

private:
	Ui::QtPCDClass ui;
	int loadSTL(string fileName, int scale);  // loader
	vector<int> pointX;
	vector<int> pointY;

private slots:
	void stlScale1();  // scale 1 - for original case & PolyFit case
	void stlScale10();  // scale 10 - for Ball-pivoting case
	void stlScale1000();  // scale 1000 - for Poisson case
};
